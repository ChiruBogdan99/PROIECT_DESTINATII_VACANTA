package com.example.tema3chiru;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import Models.ToDo;
import MySingleton.MySingleton;

//import com.google.android.material.floatingactionbutton.FloatingActionButton;
//import com.google.android.material.snackbar.Snackbar;

public class ToDosActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private Integer userId;
    private String currentTitle;

    public void setCurrentTitle(String newTitle){
        this.currentTitle = newTitle;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_dos);

        Bundle bundle = getIntent().getExtras();
        userId = 1;

        if(bundle != null)
            this.userId = bundle.getInt("id");

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        getToDos();

    }


    private void getToDos(){
        String JSON_URL = "https://my-json-server.typicode.com/ChiruBogdan99/details/details?id=" + this.userId;
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(JSON_URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                List<ToDo> toDos = new ArrayList<>();
                for (int i = 0; i < response.length(); i++) {
                    try {
                        ToDo toDo = new ToDo();
                        JSONObject toDoJSON = response.getJSONObject(i);
                        toDo.id = toDoJSON.getInt("id");
                        toDo.name = toDoJSON.getString("name");
                        toDo.details = toDoJSON.getString("details");
                        toDos.add(toDo);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                ToDosRecyclerView(toDos);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("Eroare la conectare VOLLEY" + error.getMessage());
            }
        });

        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(jsonArrayRequest);
    }

    private void ToDosRecyclerView(List<ToDo> toDos){
        ToDosDisplayAdapter adapter = new ToDosDisplayAdapter(this, toDos);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }


    public void showFragment(){
        FragmentManager mFragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();

        Fragment currentFragment = mFragmentManager.findFragmentByTag("pickersFragment");
        if(currentFragment != null)
            fragmentTransaction.remove(currentFragment);

        fragmentTransaction.add(R.id.frameLayout,new PickersFragment(this.currentTitle), "pickersFragment").commit();
    }



}
