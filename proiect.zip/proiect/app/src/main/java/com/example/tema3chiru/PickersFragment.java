package com.example.tema3chiru;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import androidx.fragment.app.Fragment;


public class PickersFragment extends Fragment {

    private Integer currentHour = null;
    private Integer currentMinute = null;
    private Integer currentYear = null;
    private Integer currentMonth = null;
    private Integer currentDay = null;


    private String currentToDoTitle = null;

    public PickersFragment(String newTitle) {
        currentToDoTitle = newTitle;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pickers, container, false);


        final TextView dateView = view.findViewById(R.id.dateTextView);
        final Button btnDatePicker = view.findViewById(R.id.dateButton);

        final Button btnOpen =  view.findViewById(R.id.openmaps);
        final Button btnList = view.findViewById(R.id.btnListDest);


        btnDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                currentYear = year;
                                currentMonth = monthOfYear;
                                currentDay = dayOfMonth;
                                dateView.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, 2020, 0, 0);
                datePickerDialog.show();
            }
        });

        btnOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(getActivity(),MapsActivity.class);
                in.putExtra("some","some data");
                startActivity(in);
            }
        });

        btnList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(getActivity(),ListActivity.class);
                in.putExtra("some","some data");
                startActivity(in);
            }
        });
        return view;
    }



}
