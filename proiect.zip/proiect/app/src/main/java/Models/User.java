package Models;

public class User {
    public int id;
    public String name;
    public String username;
}
