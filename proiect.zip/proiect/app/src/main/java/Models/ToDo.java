package Models;

public class ToDo {
    public Integer id;
    public String name;
    public String details;
}
